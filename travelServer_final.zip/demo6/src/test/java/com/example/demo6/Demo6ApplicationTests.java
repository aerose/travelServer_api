package com.example.demo6;

import com.example.demo6.dao.UserEntityMapper;
import com.example.demo6.service.IUserService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Date;

@SpringBootTest
class Demo6ApplicationTests {

    @Test
    void contextLoads() {


    }

}
