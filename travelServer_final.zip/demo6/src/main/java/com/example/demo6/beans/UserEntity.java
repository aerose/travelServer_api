package com.example.demo6.beans;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;





@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserEntity {
    private Integer userid;

    private String useraccount;

    private String userpassword;

    private String username;

    private String usersex;

    private String userphone;

    private String useraddress;

    private String useremail;

    private String usernation;

    private Date usercreatetime;

    private Date userchangetime;

    private String userremarks;

}
