package com.example.demo6.service;

import com.example.demo6.beans.RemarkEntity;

import java.util.List;
import java.util.Map;

public interface IRemarkService {

    public List<Object> searchByUserId(int userid);
    public List<Object> searchByScenicId(int scenicid);
    public int release(RemarkEntity remarkEntity);
    public int modify(RemarkEntity remarkEntity);
    public int delete(int remarkid);
}
