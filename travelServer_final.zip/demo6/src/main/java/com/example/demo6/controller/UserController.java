package com.example.demo6.controller;

import com.google.common.collect.Lists;
import com.example.demo6.beans.UserEntity;
import com.example.demo6.returnJson.user.*;
import com.example.demo6.service.IUserService;

import com.example.demo6.utils.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
public class UserController {


    @Autowired
    private IUserService iUserService;


    @RequestMapping(value = "/api/user/login", method = RequestMethod.POST, headers = "Accept=application/json")
    public UserLoginReturnJson login(@RequestBody UserEntity userEntity) {
        UserEntity inputUser = iUserService.login(userEntity);
        UserLoginReturnJson userLoginReturnJson = new UserLoginReturnJson();
        try {
            if (inputUser == null) {
                userLoginReturnJson.setError_code("1001");
            } else {
                userLoginReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userLoginReturnJson;
    }


    @RequestMapping(value = "/api/user/info/{useraccount}", method = RequestMethod.GET, headers = "Accept=application/json")
    public UserInfoReturnJson info(@PathVariable("useraccount") String useraccount) {
        UserEntity inputUser = iUserService.info(useraccount);
        UserInfoReturnJson userInfoReturnJson = new UserInfoReturnJson();
        try {
            if (inputUser == null) {
                userInfoReturnJson.setError_code("1011");
            } else {
                userInfoReturnJson.setError_code("0");
                userInfoReturnJson.setUserId(inputUser.getUserid());
                userInfoReturnJson.setUserAccount(inputUser.getUseraccount());
                userInfoReturnJson.setUserPassword(inputUser.getUserpassword());
                userInfoReturnJson.setUserName(inputUser.getUsername());
                userInfoReturnJson.setUserSex(inputUser.getUsersex());
                userInfoReturnJson.setUserPhone(inputUser.getUserphone());
                userInfoReturnJson.setUserAddress(inputUser.getUseraddress());
                userInfoReturnJson.setUserEmail(inputUser.getUseremail());
                userInfoReturnJson.setUserNation(inputUser.getUsernation());
                userInfoReturnJson.setUserCreateTime(inputUser.getUsercreatetime());
                userInfoReturnJson.setUserChangeTime(inputUser.getUserchangetime());
                userInfoReturnJson.setUserRemarks(inputUser.getUserremarks());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userInfoReturnJson;
    }


    @RequestMapping(value = "/api/user/create", method = RequestMethod.POST, headers = "Accept=application/json")
    public UserCreateReturnJson create(@RequestBody UserEntity userEntity) {
        Date nowDate = DateUtil.getCreateTime();
        userEntity.setUsercreatetime(nowDate);
        userEntity.setUserchangetime(nowDate);
        UserCreateReturnJson userCreateReturnJson = new UserCreateReturnJson();

        if(iUserService.info(userEntity.getUseraccount()) != null){
            userCreateReturnJson.setError_code("1321");
        }
        else {
            int flag = iUserService.create(userEntity);
            try {
                if (flag == 0) {
                    userCreateReturnJson.setError_code("1322");
                } else {
                    userCreateReturnJson.setError_code("0");
                }
            } catch (Exception e) {
                e.printStackTrace();

            }
        }
        return userCreateReturnJson;
    }


    @RequestMapping(value = "/api/user/modify", method = RequestMethod.POST, headers = "Accept=application/json")
    public UserModifyReturnJson modify(@RequestBody UserEntity userEntity) {
        Date nowDate = DateUtil.getCreateTime();
        userEntity.setUserchangetime(nowDate);
        int flag = iUserService.modify(userEntity);


        UserModifyReturnJson userModifyReturnJson = new UserModifyReturnJson();
        try {
            if (flag == 0) {
                userModifyReturnJson.setError_code("1331");
            } else {
                userModifyReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userModifyReturnJson;
    }


    @RequestMapping(value = "/api/user/delete", method = RequestMethod.POST, headers = "Accept=application/json")
    public UserDeleteReturnJson delete(@RequestBody UserEntity userEntity) {

        UserDeleteReturnJson userDeleteReturnJson = new UserDeleteReturnJson();
        if(iUserService.findById(userEntity.getUserid()) == null){
            userDeleteReturnJson.setError_code("1191");
        }
        else {
            try {
                iUserService.delete(userEntity.getUserid());
                userDeleteReturnJson.setError_code("0");
            } catch (Exception e) {
                userDeleteReturnJson.setError_code("1192");
                e.printStackTrace();
            }
        }
        return userDeleteReturnJson;
    }

    @RequestMapping(path = {"/api/user/show/{page}/{pagesize}", "/api/user/show/{page}"}, method = RequestMethod.GET, headers = "Accept=application/json")
    public UserShowReturnJson show(@PathVariable(value="page") int page, @PathVariable(value="pagesize",required = false) Integer pagesize) {

        if(pagesize == null){
            pagesize = 10;
        }
        UserShowReturnJson userShowReturnJson = new UserShowReturnJson();
        List<Object> result = iUserService.show();


        int total_page = result.toArray().length/pagesize;
        if(result.toArray().length%pagesize != 0){
            total_page +=1;
        }
        userShowReturnJson.setTotal_page(total_page);

        if(page > total_page || page <= 0){
            userShowReturnJson.setError_code("1501");
        }
        else {
            List<List<Object>> partition = Lists.partition(result, pagesize);
            userShowReturnJson.setError_code("0");
            userShowReturnJson.setData(partition.get(page - 1));
        }
        return userShowReturnJson;
    }


}

