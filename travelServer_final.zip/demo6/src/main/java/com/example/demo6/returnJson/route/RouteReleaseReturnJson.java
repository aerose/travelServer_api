package com.example.demo6.returnJson.route;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RouteReleaseReturnJson {
    private String error_code;
}
