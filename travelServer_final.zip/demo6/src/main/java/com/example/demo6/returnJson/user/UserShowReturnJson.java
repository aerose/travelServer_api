package com.example.demo6.returnJson.user;


import com.example.demo6.beans.UserEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserShowReturnJson {
    private String error_code;
    private int total_page;
    private Object data;
}
