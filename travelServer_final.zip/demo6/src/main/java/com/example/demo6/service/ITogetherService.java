package com.example.demo6.service;


import com.example.demo6.beans.TogetherEntity;
import java.util.List;
import java.util.Map;

public interface ITogetherService {

    public List<Object> searchByUserId(int userid);
    public List<Object> searchByScenicId(int scenicid);
    public int release(TogetherEntity togetherEntity);

    public int modify(TogetherEntity togetherEntity);

    public int delete(int togetherid);
}
