package com.example.demo6.service.impl;


import com.example.demo6.beans.ScenicEntity;
import com.example.demo6.dao.ScenicEntityMapper;
import com.example.demo6.service.IScenicService;
import com.example.demo6.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class IScenicServiceImpl implements IScenicService {
    @Autowired
    private ScenicEntityMapper scenicEntityMapper;

    @Override
    public List<Object> show(){
        List<Object> resultList = new ArrayList<>();
        List<Map<String,Object>> proResult = scenicEntityMapper.show();
        for(Map<String,Object> proobj : proResult){
            resultList.add(proobj);
        }
        return resultList;
    }

    @Override
    public List<Object> searchByString(String searchstring){
        List<Object> resultList = new ArrayList<>();
        List<Map<String,Object>> proResult = scenicEntityMapper.searchByString(searchstring);
        for(Map<String,Object> proobj : proResult){
            resultList.add(proobj);
        }
        return resultList;
    }
    @Override
    public ScenicEntity searchById(int scenicid){
        return  scenicEntityMapper.searchById(scenicid);
    }

    @Override
    public int release(ScenicEntity scenicEntity){
        return scenicEntityMapper.release(scenicEntity);
    }

    @Override
    public int delete(int scenicid){
        return scenicEntityMapper.delete(scenicid);
    }

    @Override
    public int modify(ScenicEntity scenicEntity){
        return scenicEntityMapper.modify(scenicEntity);
    }
}
