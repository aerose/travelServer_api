package com.example.demo6.inputJson.scenic;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScenicSearchByNameInputJson {
    private String searchstring;
    private int pagesize = 10;
    private int page;
}
