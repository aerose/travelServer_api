package com.example.demo6.service;

import com.example.demo6.beans.UserEntity;

import java.util.List;
import java.util.Map;

public interface IUserService {
    public UserEntity login(UserEntity userEntity);
    public UserEntity info(String useraccount);
    public int create(UserEntity userEntity);
    public int modify(UserEntity userEntity);
    public int delete(int userid);
    public List<Object> show();
    public UserEntity findById(int userid);
    public UserEntity findByAccount(String useraccount);
}
