package com.example.demo6.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class RouteEntity {

    private Integer routeid;

    private Integer scenicid;

    private String routename;

    private String routeintroduction;

    private String routetime;

    private Date routecreatetime;

    private Date routechangetime;
}
