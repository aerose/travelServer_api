package com.example.demo6.returnJson.scenic;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScenicSearchByIdJson {
    private String error_code;
    private Integer scenicId;
    private String scenicName;
    private String scenicIntroduction;
    private String scenicPrice;
    private String scenicCity;
    private String scenicLocation;
    private String scenicOpenTime;
    private String scenicCloseTime;
    private String scenicPic;
    private String scenicGrade;
    private String scenicClass;
    private String scenicStatus;
    private Date scenicCreateTime;
    private Date scenicChangeTime;
}
