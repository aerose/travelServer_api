package com.example.demo6.inputJson.together;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TogetherSearchByScenicIdInputJson {
    private int scenicid;
    private int pagesize = 10;
    private int page;
}
