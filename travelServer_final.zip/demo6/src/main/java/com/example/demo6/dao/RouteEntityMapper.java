package com.example.demo6.dao;

import com.example.demo6.beans.RouteEntity;
import com.example.demo6.beans.ScenicEntity;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public interface RouteEntityMapper {
    public List<Map<String,Object>> show(int scenicid);
    public int release(RouteEntity routeEntity);
    public int modify(RouteEntity routeEntity);
    public int delete(int routeid);
}
