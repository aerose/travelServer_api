package com.example.demo6.beans;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class RemarkEntity {
    private Integer remarkid;

    private Integer userid;

    private Integer scenicid;

    private String username;

    private String remarkdetails;

    private Date remarkcreatetime;

    private Date remarkchangetime;
}
