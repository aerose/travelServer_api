package com.example.demo6.service;

import com.example.demo6.beans.RouteEntity;

import java.util.List;

public interface IRouteService {

    public List<Object> show(int scenicid);
    public int release(RouteEntity routeEntity);
    public int modify(RouteEntity routeEntity);
    public int delete(int routeid);
}
