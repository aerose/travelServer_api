package com.example.demo6.service.impl;


import com.example.demo6.beans.RouteEntity;
import com.example.demo6.dao.RouteEntityMapper;
import com.example.demo6.service.IRouteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class IRouteServiceImpl implements IRouteService {

    @Autowired
    private RouteEntityMapper routeEntityMapper;

    @Override
    public List<Object> show(int scenicid){
        List<Object> resultList = new ArrayList<>();
        List<Map<String,Object>> proResult = routeEntityMapper.show(scenicid);
        for(Map<String,Object> proobj : proResult){
            resultList.add(proobj);
        }
        return resultList;
    }

    @Override
    public int release(RouteEntity routeEntity){
        return routeEntityMapper.release(routeEntity);
    }

    @Override
    public int modify(RouteEntity routeEntity){
        return routeEntityMapper.modify(routeEntity);
    }

    @Override
    public int delete(int routeid){
        return routeEntityMapper.delete(routeid);
    }
}
