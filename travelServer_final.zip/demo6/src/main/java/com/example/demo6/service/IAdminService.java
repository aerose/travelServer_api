package com.example.demo6.service;

import java.lang.String;


import com.example.demo6.beans.AdminEntity;

public interface IAdminService {
    public AdminEntity login(AdminEntity adminEntity);

    public AdminEntity info(String adminAccount);

    public int create(AdminEntity adminEntity);

    public int modify(AdminEntity adminEntity);

    public int delete(int adminid);
}
