package com.example.demo6.returnJson.together;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TogetherDeleteReturnJson {
    private String error_code;

}
