package com.example.demo6.service.impl;

import com.example.demo6.beans.RemarkEntity;
import com.example.demo6.dao.RemarkEntityMapper;
import com.example.demo6.service.IRemarkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class IRemarkServiceImpl implements IRemarkService {

    @Autowired
    private RemarkEntityMapper remarkEntityMapper;

    @Override
    public List<Object> searchByUserId(int userid){
        List<Object> resultList = new ArrayList<>();
        List<Map<String,Object>> proResult = remarkEntityMapper.searchByUserId(userid);
        for(Map<String,Object> proobj : proResult){
            resultList.add(proobj);
        }
        return resultList;
    }

    @Override
    public List<Object> searchByScenicId(int scenicid){
        List<Object> resultList = new ArrayList<>();
        List<Map<String,Object>> proResult = remarkEntityMapper.searchByScenicId(scenicid);
        for(Map<String,Object> proobj : proResult){
            resultList.add(proobj);
        }
        return resultList;
    }

    @Override
    public int release(RemarkEntity remarkEntity){
        return remarkEntityMapper.release(remarkEntity);
    }

    @Override
    public int modify(RemarkEntity remarkEntity){
        return remarkEntityMapper.modify(remarkEntity);
    }

    @Override
    public int delete(int remarkid){
        return remarkEntityMapper.delete(remarkid);
    }

}
