package com.example.demo6.controller;

import com.example.demo6.inputJson.remark.RemarkSearchByScenicIdInputJson;
import com.google.common.collect.Lists;
import com.example.demo6.inputJson.remark.RemarkSearchByUserIdInputJson;
import com.example.demo6.returnJson.remark.*;
import com.example.demo6.returnJson.route.RouteDeleteReturnJson;
import com.example.demo6.returnJson.route.RouteModifyReturnJson;
import com.example.demo6.service.IScenicService;
import com.example.demo6.utils.DateUtil;
import com.example.demo6.returnJson.route.RouteReleaseReturnJson;
import com.example.demo6.service.IUserService;
import com.example.demo6.beans.RemarkEntity;
import com.example.demo6.beans.RouteEntity;
import com.example.demo6.returnJson.route.RouteShowReturnJson;
import com.example.demo6.service.IRemarkService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
public class RemarkController {

    @Autowired
    private IRemarkService iRemarkService;

    @Autowired
    private IUserService iUserService;

    @Autowired
    private  IScenicService  iScenicService;


    @RequestMapping(value = "/api/remark/searchByUserId", method = RequestMethod.POST, headers = "Accept=application/json")
    public RemarkSearchByUserIdReturnJson searchByUserId(@RequestBody RemarkSearchByUserIdInputJson remarkSearchByUserIdInputJson) {


        int page = remarkSearchByUserIdInputJson.getPage();
        int pagesize = remarkSearchByUserIdInputJson.getPagesize();

        RemarkSearchByUserIdReturnJson remarkSearchByUserIdReturnJson = new RemarkSearchByUserIdReturnJson();

        if (iUserService.findById(remarkSearchByUserIdInputJson.getUserid()) == null) {
            remarkSearchByUserIdReturnJson.setError_code("1021");
        } else {
            List<Object> result = iRemarkService.searchByUserId(remarkSearchByUserIdInputJson.getUserid());

            int total_page = result.toArray().length/pagesize;
            if(result.toArray().length%pagesize != 0){
                total_page +=1;
            }
            remarkSearchByUserIdReturnJson.setTotal_page(total_page);

            if(page > total_page || page <= 0){
                remarkSearchByUserIdReturnJson.setError_code("1022");
            }
            else {
                List<List<Object>> partition = Lists.partition(result, pagesize);
                remarkSearchByUserIdReturnJson.setError_code("0");
                remarkSearchByUserIdReturnJson.setData(partition.get(page - 1));
            }
        }
            return remarkSearchByUserIdReturnJson;

    }

    @RequestMapping(value = "/api/remark/searchByScenicId", method = RequestMethod.POST, headers = "Accept=application/json")
    public RemarkSearchByScenicIdReturnJson searchByScenicId(@RequestBody RemarkSearchByScenicIdInputJson remarkSearchByScenicIdInputJson) {

        int page = remarkSearchByScenicIdInputJson.getPage();
        int pagesize = remarkSearchByScenicIdInputJson.getPagesize();

        RemarkSearchByScenicIdReturnJson remarkSearchByScenicIdReturnJson = new RemarkSearchByScenicIdReturnJson();


        if (iUserService.findById(remarkSearchByScenicIdInputJson.getScenicid()) == null) {
            remarkSearchByScenicIdReturnJson.setError_code("1041");
        } else {
            List<Object> result = iRemarkService.searchByScenicId(remarkSearchByScenicIdInputJson.getScenicid());


            int total_page = result.toArray().length/pagesize;
            if(result.toArray().length%pagesize != 0){
                total_page +=1;
            }
            remarkSearchByScenicIdReturnJson.setTotal_page(total_page);

            if(page > total_page || page <= 0){
                remarkSearchByScenicIdReturnJson.setError_code("1142");
            }
            else {
                List<List<Object>> partition = Lists.partition(result, pagesize);
                remarkSearchByScenicIdReturnJson.setError_code("0");
                remarkSearchByScenicIdReturnJson.setData(partition.get(page - 1));
            }
        }
        return remarkSearchByScenicIdReturnJson;

    }


    @RequestMapping(value = "/api/remark/release", method = RequestMethod.POST, headers = "Accept=application/json")
    public RemarkReleaseReturnJson create(@RequestBody RemarkEntity remarkEntity) {
        Date nowDate = DateUtil.getCreateTime();
        remarkEntity.setRemarkcreatetime(nowDate);
        remarkEntity.setRemarkchangetime(nowDate);

        RemarkReleaseReturnJson remarkReleaseReturnJson = new RemarkReleaseReturnJson();

        if(iScenicService.searchById(remarkEntity.getScenicid()) == null){
            remarkReleaseReturnJson.setError_code("1061");
        }
        else if(iUserService.findById(remarkEntity.getUserid()) == null){
            remarkReleaseReturnJson.setError_code("1062");
        }
        else {
            int flag = iRemarkService.release(remarkEntity);
            try {
                if (flag == 0) {
                    remarkReleaseReturnJson.setError_code("1063");
                } else {
                    remarkReleaseReturnJson.setError_code("0");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return remarkReleaseReturnJson;
    }



    @RequestMapping(value = "/api/remark/modify", method = RequestMethod.POST, headers = "Accept=application/json")
    public RemarkModifyReturnJson modify(@RequestBody RemarkEntity remarkEntity) {
        Date nowDate = DateUtil.getCreateTime();
        remarkEntity.setRemarkchangetime(nowDate);
        RemarkModifyReturnJson remarkModifyReturnJson = new RemarkModifyReturnJson();

        int flag = iRemarkService.modify(remarkEntity);
        try {
            if (flag == 0) {
                remarkModifyReturnJson.setError_code("1341");
            } else {
                remarkModifyReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return remarkModifyReturnJson;
    }

    @RequestMapping(value = "/api/remark/delete", method = RequestMethod.POST, headers = "Accept=application/json")
    public RemarkDeleteReturnJson delete(@RequestBody RemarkEntity remarkEntity) {
        int result = iRemarkService.delete(remarkEntity.getRemarkid());
        RemarkDeleteReturnJson remarkDeleteReturnJson = new RemarkDeleteReturnJson();
        try {
            if (result == 0) {
                remarkDeleteReturnJson.setError_code("1051");
            } else {
                remarkDeleteReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return remarkDeleteReturnJson;
    }


}