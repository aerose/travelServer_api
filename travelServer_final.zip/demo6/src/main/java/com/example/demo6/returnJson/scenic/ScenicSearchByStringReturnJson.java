package com.example.demo6.returnJson.scenic;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScenicSearchByStringReturnJson {
    private String error_code;
    private int total_page;
    private Object data;
}
