package com.example.demo6.dao;

import com.example.demo6.beans.ScenicEntity;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
@Repository
public interface ScenicEntityMapper {
    public List<Map<String,Object>> show();
    public List<Map<String,Object>> searchByString(String searchstring);
    public ScenicEntity searchById(int scenicid);
    public int release(ScenicEntity scenicEntity);
    public int delete(int scenicid);
    public int modify(ScenicEntity scenicEntity);
}
