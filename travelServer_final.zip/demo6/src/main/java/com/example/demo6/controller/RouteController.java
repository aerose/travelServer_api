package com.example.demo6.controller;

import com.google.common.collect.Lists;
import com.example.demo6.service.IScenicService;
import com.example.demo6.returnJson.route.RouteDeleteReturnJson;
import com.example.demo6.returnJson.route.RouteModifyReturnJson;
import com.example.demo6.returnJson.scenic.ScenicDeleteReturnJson;
import com.example.demo6.returnJson.scenic.ScenicModifyReturnJson;
import com.example.demo6.utils.DateUtil;

import com.example.demo6.beans.RouteEntity;
import com.example.demo6.beans.ScenicEntity;
import com.example.demo6.returnJson.route.RouteReleaseReturnJson;
import com.example.demo6.returnJson.route.RouteShowReturnJson;
import com.example.demo6.service.IRouteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
public class RouteController {

    @Autowired
    private IRouteService iRouteService;

    @Autowired
    private IScenicService iScenicService;



    @RequestMapping(path = {"/api/route/show/{scenicid}/{page}/{pagesize}", "/api/route/show/{scenicid}/{page}"}, method = RequestMethod.GET, headers = "Accept=application/json")
    public RouteShowReturnJson show(@PathVariable("scenicid") int scenicid,@PathVariable(value="page")int page, @PathVariable(value="pagesize",required = false) Integer pagesize){
        if(pagesize == null) {
            pagesize = 10;
        }
        RouteShowReturnJson routeShowReturnJson = new RouteShowReturnJson();
        List<Object> result = iRouteService.show(scenicid);
        int total_page = result.toArray().length/pagesize;
        if(result.toArray().length % pagesize != 0){
            total_page +=1;
        }
        routeShowReturnJson.setTotal_page(total_page);

        if(page > total_page || page <= 0){
            routeShowReturnJson.setError_code("1171");
        }
        else {
            List<List<Object>> partition = Lists.partition(result, pagesize);
            routeShowReturnJson.setError_code("0");
            routeShowReturnJson.setData(partition.get(page - 1));
        }
        return routeShowReturnJson;
    }


    @RequestMapping(value = "/api/route/release", method = RequestMethod.POST, headers = "Accept=application/json")
    public RouteReleaseReturnJson create(@RequestBody RouteEntity routeEntity) {
        Date nowDate = DateUtil.getCreateTime();
        routeEntity.setRoutecreatetime(nowDate);
        routeEntity.setRoutechangetime(nowDate);
        RouteReleaseReturnJson routeReleaseReturnJson = new RouteReleaseReturnJson();

        if(iScenicService.searchById(routeEntity.getScenicid()) == null){
            routeReleaseReturnJson.setError_code("1151");
        }
        else {

            int flag = iRouteService.release(routeEntity);
            try {
                if (flag == 0) {
                    routeReleaseReturnJson.setError_code("1152");
                } else {
                    routeReleaseReturnJson.setError_code("0");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return routeReleaseReturnJson;
    }

    @RequestMapping(value = "/api/route/modify", method = RequestMethod.POST, headers = "Accept=application/json")
    public RouteModifyReturnJson modify(@RequestBody RouteEntity routeEntity) {
        Date nowDate = DateUtil.getCreateTime();
        routeEntity.setRoutechangetime(nowDate);
        int flag = iRouteService.modify(routeEntity);


        RouteModifyReturnJson routeModifyReturnJson = new RouteModifyReturnJson();
        try {
            if (flag == 0) {
                routeModifyReturnJson.setError_code("1351");
            } else {
                routeModifyReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return routeModifyReturnJson;
    }


    @RequestMapping(value = "/api/route/delete", method = RequestMethod.POST, headers = "Accept=application/json")
    public RouteDeleteReturnJson delete(@RequestBody RouteEntity routeEntity) {
        int result = iRouteService.delete(routeEntity.getRouteid());
        RouteDeleteReturnJson routeDeleteReturnJson = new RouteDeleteReturnJson();
        try {
            if (result == 0) {
                routeDeleteReturnJson.setError_code("1161");
            } else {
                routeDeleteReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return routeDeleteReturnJson;
    }

}
