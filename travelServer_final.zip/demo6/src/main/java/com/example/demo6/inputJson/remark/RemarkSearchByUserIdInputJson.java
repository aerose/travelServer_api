package com.example.demo6.inputJson.remark;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RemarkSearchByUserIdInputJson {
    private int userid;
    private int pagesize = 10;
    private int page;
}
