package com.example.demo6.returnJson.user;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserInfoReturnJson {
    private String error_code;
    private int userId;
    private String userAccount;
    private String userPassword;
    private String userName;
    private String userSex;
    private String userPhone;
    private String userAddress;
    private String userEmail;
    private String userNation;
    private Date userCreateTime;
    private Date userChangeTime;
    private String userRemarks;
}
