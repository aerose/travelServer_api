package com.example.demo6.returnJson.admin;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminInfoReturnJson {
    private String error_code;
    private int adminId;
    private String adminAccount;
    private String adminPassword;
    private String adminName;
    private String adminDuty;
    private String adminDescription;
    private String adminIfFreeze;
    private Date adminCreateTime;
    private Date adminChangeTime;

}
