package com.example.demo6.dao;


import com.example.demo6.beans.TogetherEntity;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
public interface TogetherEntityMapper {
    public List<Map<String,Object>> searchByUserId(int userid);
    public List<Map<String,Object>> searchByScenicId(int scenicid);
    public int release(TogetherEntity togetherEntity);
    public int modify(TogetherEntity togetherEntity);
    public int delete(int togetherid);
}
