package com.example.demo6.service.impl;

import com.example.demo6.beans.AdminEntity;
import com.example.demo6.dao.AdminEntityMapper;
import com.example.demo6.service.IAdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IAdminServiceImpl implements IAdminService {

    @Autowired
    private AdminEntityMapper adminEntityMapper;

    @Override
    public AdminEntity login(AdminEntity adminEntity) { return adminEntityMapper.login(adminEntity); }

    @Override
    public AdminEntity info(String adminaccount) {return adminEntityMapper.info(adminaccount);}

    @Override
    public int create(AdminEntity adminEntity) {return adminEntityMapper.create(adminEntity);}

    @Override
    public int modify(AdminEntity adminEntity) {return adminEntityMapper.modify(adminEntity);}

    @Override
    public int delete(int adminid) {return adminEntityMapper.delete(adminid);}


}
