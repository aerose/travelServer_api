package com.example.demo6.service.impl;


import com.example.demo6.beans.TogetherEntity;
import com.example.demo6.dao.TogetherEntityMapper;
import com.example.demo6.service.ITogetherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
@Service
public class ITogetherServiceImpl implements ITogetherService {

    @Autowired
    private TogetherEntityMapper togetherEntityMapper;

    @Override
    public List<Object> searchByUserId(int userid){
        List<Object> resultList = new ArrayList<>();
        List<Map<String,Object>> proResult = togetherEntityMapper.searchByUserId(userid);
        for(Map<String,Object> proobj : proResult){
            resultList.add(proobj);
        }
        return resultList;
    }

    @Override
    public List<Object> searchByScenicId(int scenicid){
        List<Object> resultList = new ArrayList<>();
        List<Map<String,Object>> proResult = togetherEntityMapper.searchByScenicId(scenicid);
        for(Map<String,Object> proobj : proResult){
            resultList.add(proobj);
        }
        return resultList;
    }


    @Override
    public int release(TogetherEntity togetherEntity){
        return togetherEntityMapper.release(togetherEntity);
    }

    @Override
    public int modify(TogetherEntity togetherEntity){
        return togetherEntityMapper.modify(togetherEntity);
    }

    @Override
    public int delete(int togetherid){
        return togetherEntityMapper.delete(togetherid);
    }
}
