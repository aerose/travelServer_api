package com.example.demo6.controller;


import com.google.common.collect.Lists;
import com.example.demo6.returnJson.scenic.*;
import com.example.demo6.returnJson.user.UserModifyReturnJson;
import com.example.demo6.utils.DateUtil;
import com.example.demo6.beans.ScenicEntity;
import com.example.demo6.beans.UserEntity;
import com.example.demo6.inputJson.scenic.ScenicSearchByNameInputJson;
import com.example.demo6.returnJson.user.UserCreateReturnJson;
import com.example.demo6.returnJson.user.UserInfoReturnJson;
import com.example.demo6.returnJson.user.UserShowReturnJson;
import com.example.demo6.service.IScenicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RestController
public class ScenicController {

    @Autowired
    private IScenicService iScenicService;

    @RequestMapping(path = {"/api/scenic/show/{page}/{pagesize}", "/api/scenic/show/{page}"}, method = RequestMethod.GET, headers = "Accept=application/json")
    public ScenicShowReturnJson show(@PathVariable(value="page") int page, @PathVariable(value="pagesize",required = false) Integer pagesize){

        if(pagesize == null) {
            pagesize = 10;
        }
        ScenicShowReturnJson scenicShowReturnJson = new ScenicShowReturnJson();
        List<Object> result = iScenicService.show();
        int total_page = result.toArray().length/pagesize;
        if(result.toArray().length%pagesize != 0){
            total_page +=1;
        }
        scenicShowReturnJson.setTotal_page(total_page);

        if(page > total_page || page <= 0){
            scenicShowReturnJson.setError_code("1121");
        }
        else {
            List<List<Object>> partition = Lists.partition(result, pagesize);
            scenicShowReturnJson.setError_code("0");
            scenicShowReturnJson.setData(partition.get(page - 1));
        }
        return scenicShowReturnJson;
    }

    @RequestMapping(value = "/api/scenic/searchByString", method = RequestMethod.POST, headers = "Accept=application/json")
    public ScenicSearchByStringReturnJson searchByString(@RequestBody ScenicSearchByNameInputJson scenicSearchByNameInputJson){

        String searchstring = scenicSearchByNameInputJson.getSearchstring();
        int page = scenicSearchByNameInputJson.getPage();
        int pagesize = scenicSearchByNameInputJson.getPagesize();

        ScenicSearchByStringReturnJson scenicSearchByStringReturnJson = new ScenicSearchByStringReturnJson();
        List<Object> result = iScenicService.searchByString(searchstring);
        int total_page = result.toArray().length/pagesize;
        if(result.toArray().length%pagesize != 0){
            total_page +=1;
        }
        scenicSearchByStringReturnJson.setTotal_page(total_page);

        if(page > total_page || page <= 0){
            scenicSearchByStringReturnJson.setError_code("1101");
        }
        else {
            List<List<Object>> partition = Lists.partition(result, pagesize);
            scenicSearchByStringReturnJson.setError_code("0");
            scenicSearchByStringReturnJson.setData(partition.get(page - 1));
        }
        return scenicSearchByStringReturnJson;
    }

    @RequestMapping(value = "/api/scenic/searchById/{scenicid}", method = RequestMethod.GET, headers = "Accept=application/json")
    public ScenicSearchByIdJson info(@PathVariable("scenicid") int scenicid) {

        ScenicEntity inputScenic = iScenicService.searchById(scenicid);

        ScenicSearchByIdJson scenicSearchByIdJson = new ScenicSearchByIdJson();
        try {
            if (inputScenic == null) {
                scenicSearchByIdJson.setError_code("1111");
            } else {
                scenicSearchByIdJson.setError_code("0");
                scenicSearchByIdJson.setScenicId(inputScenic.getScenicid());
                scenicSearchByIdJson.setScenicName(inputScenic.getScenicname());
                scenicSearchByIdJson.setScenicIntroduction(inputScenic.getScenicintroduction());
                scenicSearchByIdJson.setScenicPrice(inputScenic.getScenicprice());
                scenicSearchByIdJson.setScenicCity(inputScenic.getSceniccity());
                scenicSearchByIdJson.setScenicLocation(inputScenic.getSceniclocation());
                scenicSearchByIdJson.setScenicOpenTime(inputScenic.getScenicopentime());
                scenicSearchByIdJson.setScenicCloseTime(inputScenic.getScenicclosetime());
                scenicSearchByIdJson.setScenicPic(inputScenic.getScenicpic());
                scenicSearchByIdJson.setScenicGrade(inputScenic.getScenicgrade());
                scenicSearchByIdJson.setScenicClass(inputScenic.getScenicclass());
                scenicSearchByIdJson.setScenicStatus(inputScenic.getScenicstatus());
                scenicSearchByIdJson.setScenicCreateTime(inputScenic.getSceniccreatetime());
                scenicSearchByIdJson.setScenicChangeTime(inputScenic.getSceniccreatetime());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return scenicSearchByIdJson;
    }

    @RequestMapping(value = "/api/scenic/release", method = RequestMethod.POST, headers = "Accept=application/json")
    public ScenicReleaseReturnJson release(@RequestBody ScenicEntity scenicEntity) {
        Date nowDate = DateUtil.getCreateTime();
        scenicEntity.setSceniccreatetime(nowDate);
        scenicEntity.setScenicchangetime(nowDate);
        ScenicReleaseReturnJson scenicReleaseReturnJson = new ScenicReleaseReturnJson();


        int flag = iScenicService.release(scenicEntity);
        try {
            if (flag == 0) {
                scenicReleaseReturnJson.setError_code("1142");
            } else {
                scenicReleaseReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return scenicReleaseReturnJson;
    }

    @RequestMapping(value = "/api/scenic/delete", method = RequestMethod.POST, headers = "Accept=application/json")
    public ScenicDeleteReturnJson delete(@RequestBody ScenicEntity scenicEntity) {

        ScenicDeleteReturnJson scenicDeleteReturnJson = new ScenicDeleteReturnJson();
        if(iScenicService.searchById(scenicEntity.getScenicid()) == null){
            scenicDeleteReturnJson.setError_code("1131");
        }
        else {
            try {
                iScenicService.delete(scenicEntity.getScenicid());
                scenicDeleteReturnJson.setError_code("0");
            } catch (Exception e) {
                scenicDeleteReturnJson.setError_code("1132");
                e.printStackTrace();
            }
        }
        return scenicDeleteReturnJson;
    }

    @RequestMapping(value = "/api/scenic/modify", method = RequestMethod.POST, headers = "Accept=application/json")
    public ScenicModifyReturnJson modify(@RequestBody ScenicEntity scenicEntity) {
        Date nowDate = DateUtil.getCreateTime();
        scenicEntity.setScenicchangetime(nowDate);



        int flag = iScenicService.modify(scenicEntity);


        ScenicModifyReturnJson scenicModifyReturnJson = new ScenicModifyReturnJson();
        try {
            if (flag == 0) {
                scenicModifyReturnJson.setError_code("1511");
            } else {
                scenicModifyReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return scenicModifyReturnJson;
    }

}
