package com.example.demo6.dao;

import com.example.demo6.beans.AdminEntity;
import org.springframework.stereotype.Repository;

@Repository
public interface AdminEntityMapper {

    public AdminEntity login(AdminEntity adminEntity);

    public AdminEntity info(String adminEntity);

    public int create(AdminEntity adminEntity);

    public int modify(AdminEntity adminEntity);

    public int delete(int adminid);

}
