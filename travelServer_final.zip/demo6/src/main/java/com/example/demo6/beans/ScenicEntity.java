package com.example.demo6.beans;

import java.util.Date;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AllArgsConstructor
public class ScenicEntity {
    private Integer scenicid;

    private String scenicname;

    private String scenicintroduction;

    private String scenicprice;

    private String sceniccity;

    private String sceniclocation;

    private String scenicopentime;

    private String scenicclosetime;

    private String scenicpic;

    private String scenicgrade;

    private String scenicclass;

    private String scenicstatus;

    private Date sceniccreatetime;

    private Date scenicchangetime;
}
