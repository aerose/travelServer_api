package com.example.demo6.controller;


import com.example.demo6.service.IScenicService;
import com.example.demo6.beans.TogetherEntity;
import com.example.demo6.inputJson.together.TogetherSearchByScenicIdInputJson;
import com.example.demo6.returnJson.together.*;
import com.google.common.collect.Lists;

import com.example.demo6.utils.DateUtil;
import com.example.demo6.inputJson.together.TogetherSearchByUserIdInputJson;

import com.example.demo6.service.ITogetherService;
import com.example.demo6.service.IUserService;
import com.google.common.collect.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

@RestController
public class TogetherController {

    @Autowired
    private ITogetherService iTogetherService;

    @Autowired
    private IUserService iUserService;

    @Autowired
    private IScenicService iScenicService;



    @RequestMapping(value = "/api/together/searchByUserId", method = RequestMethod.POST, headers = "Accept=application/json")
    public TogetherSearchByUserIdReturnJson searchByUserId(@RequestBody TogetherSearchByUserIdInputJson togetherSearchByUserIdInputJson) {


        int page = togetherSearchByUserIdInputJson.getPage();
        int pagesize = togetherSearchByUserIdInputJson.getPagesize();

        TogetherSearchByUserIdReturnJson togetherSearchByUserIdReturnJson = new TogetherSearchByUserIdReturnJson();

        if (iUserService.findById(togetherSearchByUserIdInputJson.getUserid()) == null) {
            togetherSearchByUserIdReturnJson.setError_code("1031");
        } else {
            List<Object> result = iTogetherService.searchByUserId(togetherSearchByUserIdInputJson.getUserid());

            int total_page = result.toArray().length/pagesize;
            if(result.toArray().length%pagesize != 0){
                total_page +=1;
            }
            togetherSearchByUserIdReturnJson.setTotal_page(total_page);

            if(page > total_page || page <= 0){
                togetherSearchByUserIdReturnJson.setError_code("1032");
            }
            else {
                List<List<Object>> partition = Lists.partition(result, pagesize);
                togetherSearchByUserIdReturnJson.setError_code("0");
                togetherSearchByUserIdReturnJson.setData(partition.get(page - 1));
            }
        }
        return togetherSearchByUserIdReturnJson;
    }


    @RequestMapping(value = "/api/together/searchByScenicId", method = RequestMethod.POST, headers = "Accept=application/json")
    public TogetherSearchByScenicIdReturnJson searchByScenicId(@RequestBody TogetherSearchByScenicIdInputJson togetherSearchByScenicIdInputJson) {


        int page = togetherSearchByScenicIdInputJson.getPage();
        int pagesize = togetherSearchByScenicIdInputJson.getPagesize();

        TogetherSearchByScenicIdReturnJson togetherSearchByScenicIdReturnJson = new TogetherSearchByScenicIdReturnJson();

        if (iUserService.findById(togetherSearchByScenicIdInputJson.getScenicid()) == null) {
            togetherSearchByScenicIdReturnJson.setError_code("1071");
        } else {
            List<Object> result = iTogetherService.searchByUserId(togetherSearchByScenicIdInputJson.getScenicid());

            int total_page = result.toArray().length/pagesize;
            if(result.toArray().length%pagesize != 0){
                total_page +=1;
            }
            togetherSearchByScenicIdReturnJson.setTotal_page(total_page);

            if(page > total_page || page <= 0){
                togetherSearchByScenicIdReturnJson.setError_code("1072");
            }
            else {
                List<List<Object>> partition = Lists.partition(result, pagesize);
                togetherSearchByScenicIdReturnJson.setError_code("0");
                togetherSearchByScenicIdReturnJson.setData(partition.get(page - 1));
            }
        }
        return togetherSearchByScenicIdReturnJson;
    }


    @RequestMapping(value = "/api/together/release", method = RequestMethod.POST, headers = "Accept=application/json")
    public TogetherReleaseReturnJson release(@RequestBody TogetherEntity togetherEntity) {
        Date nowDate = DateUtil.getCreateTime();
        togetherEntity.setTogethercreatetime(nowDate);
        togetherEntity.setTogetherchangetime(nowDate);

        TogetherReleaseReturnJson togetherReleaseReturnJson = new TogetherReleaseReturnJson();

        if(iScenicService.searchById(togetherEntity.getScenicid()) == null){
            togetherReleaseReturnJson.setError_code("1091");
        }
        else if(iUserService.findById(togetherEntity.getUserid()) == null){
            togetherReleaseReturnJson.setError_code("1092");
        }
        else {
            int flag = iTogetherService.release(togetherEntity);
            try {
                if (flag == 0) {
                    togetherReleaseReturnJson.setError_code("1093");
                } else {
                    togetherReleaseReturnJson.setError_code("0");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return togetherReleaseReturnJson;
    }

    @RequestMapping(value = "/api/together/modify", method = RequestMethod.POST, headers = "Accept=application/json")
    public TogetherModifyReturnJson modify(@RequestBody TogetherEntity togetherEntity) {
        Date nowDate = DateUtil.getCreateTime();
        togetherEntity.setTogetherchangetime(nowDate);
        TogetherModifyReturnJson togetherModifyReturnJson = new TogetherModifyReturnJson();

        int flag = iTogetherService.modify(togetherEntity);
        try {
            if (flag == 0) {
                togetherModifyReturnJson.setError_code("1521");
            } else {
                togetherModifyReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return togetherModifyReturnJson;
    }

    @RequestMapping(value = "/api/together/delete", method = RequestMethod.POST, headers = "Accept=application/json")
    public TogetherDeleteReturnJson delete(@RequestBody TogetherEntity togetherEntity) {
        int result = iTogetherService.delete(togetherEntity.getTogetherid());
        TogetherDeleteReturnJson togetherDeleteReturnJson = new TogetherDeleteReturnJson();
        try {
            if (result == 0) {
                togetherDeleteReturnJson.setError_code("1081");
            } else {
                togetherDeleteReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return togetherDeleteReturnJson;
    }
}
