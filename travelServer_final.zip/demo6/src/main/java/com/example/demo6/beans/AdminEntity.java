package com.example.demo6.beans;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Date;





@Data
@NoArgsConstructor
@AllArgsConstructor
public class AdminEntity {
    private Integer adminid;

    private String adminaccount;

    private String adminpassword;

    private String adminname;

    private String adminduty;

    private String admindescription;

    private String adminiffreeze;

    private Date admincreatetime;

    private Date adminchangetime;


}
