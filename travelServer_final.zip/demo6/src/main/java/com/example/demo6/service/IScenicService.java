package com.example.demo6.service;

import com.example.demo6.beans.ScenicEntity;

import java.util.List;
import java.util.Map;

public interface IScenicService {

    public List<Object> show();
    public List<Object> searchByString(String searchstring);
    public ScenicEntity searchById(int scenicid);
    public int release(ScenicEntity scenicEntity);
    public int delete(int scenicid);
    public int modify(ScenicEntity scenicEntity);
}
