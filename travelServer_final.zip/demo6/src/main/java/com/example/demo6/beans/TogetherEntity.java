package com.example.demo6.beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TogetherEntity {
    private Integer togetherid;

    private Integer scenicid;

    private Integer userid;

    private String usercontact;

    private String togetherdetails;

    private String togetherstarttime;

    private String togetherendtime;

    private Date togethercreatetime;

    private Date togetherchangetime;
}
