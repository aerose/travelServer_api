package com.example.demo6.service.impl;

import com.example.demo6.beans.UserEntity;
import com.example.demo6.dao.UserEntityMapper;
import com.example.demo6.service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
public class IUserServiceImpl implements IUserService {


    @Autowired
    private UserEntityMapper userEntityMapper;

    @Override
    public UserEntity login(UserEntity userEntity){
        return userEntityMapper.login(userEntity);
    }

    @Override
    public UserEntity info(String useraccount){
        return  userEntityMapper.info(useraccount);
    }

    @Override
    public int create(UserEntity userEntity){
        return  userEntityMapper.create(userEntity);
    }

    @Override
    public int modify(UserEntity userEntity){
        return  userEntityMapper.modify(userEntity);
    }

    @Override
    public int delete(int userid){
        return userEntityMapper.delete(userid);
    }

    @Override
    public List<Object> show(){
        List<Object> resultList = new ArrayList<>();
        List<Map<String,Object>> proResult = userEntityMapper.show();
        for(Map<String,Object> proobj : proResult){
            resultList.add(proobj);
        }
        return resultList;
    }
    @Override
    public UserEntity findById(int userid){
        return userEntityMapper.findById(userid);
    }

    @Override
    public UserEntity findByAccount(String useraccount){
        return userEntityMapper.findByAccount(useraccount);
    }


}
