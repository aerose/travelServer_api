package com.example.demo6.controller;

import com.example.demo6.returnJson.admin.AdminCreateReturnJson;
import com.example.demo6.beans.AdminEntity;
import com.example.demo6.beans.UserEntity;
import com.example.demo6.returnJson.admin.*;
import com.example.demo6.returnJson.user.UserDeleteReturnJson;
import com.example.demo6.returnJson.user.UserModifyReturnJson;
import com.example.demo6.service.IAdminService;
import com.example.demo6.utils.DateUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@RestController
public class AdminController {


    @Autowired
    private IAdminService iAdminService;

    @RequestMapping(value = "api/admin/login", method = RequestMethod.POST, headers = "Accept=application/json")
    public AdminLoginReturnJson login(@RequestBody AdminEntity adminEntity) {
        AdminEntity inputAdmin = iAdminService.login(adminEntity);
        AdminLoginReturnJson adminLoginReturnJson = new AdminLoginReturnJson();
        try {
            if (inputAdmin == null) {
                adminLoginReturnJson.setError_code("1181");
            } else {
                adminLoginReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return adminLoginReturnJson;
    }

    @RequestMapping(value = "/api/admin/info/{adminaccount}", method = RequestMethod.GET, headers = "Accept=application/json")
    public AdminInfoReturnJson info(@PathVariable("adminaccount") String adminaccount){
        AdminEntity inputAdmin = iAdminService.info(adminaccount);
        AdminInfoReturnJson adminInfoReturnJson = new AdminInfoReturnJson();
        try{
            if(inputAdmin == null){
                adminInfoReturnJson.setError_code("1211");
            }else {
                adminInfoReturnJson.setError_code("0");
                adminInfoReturnJson.setAdminId(inputAdmin.getAdminid());
                adminInfoReturnJson.setAdminAccount(inputAdmin.getAdminaccount());
                adminInfoReturnJson.setAdminPassword(inputAdmin.getAdminpassword());
                adminInfoReturnJson.setAdminName(inputAdmin.getAdminname());
                adminInfoReturnJson.setAdminDuty(inputAdmin.getAdminduty());
                adminInfoReturnJson.setAdminDescription(inputAdmin.getAdmindescription());
                adminInfoReturnJson.setAdminIfFreeze(inputAdmin.getAdminiffreeze());
                adminInfoReturnJson.setAdminCreateTime(inputAdmin.getAdmincreatetime());
                adminInfoReturnJson.setAdminChangeTime(inputAdmin.getAdminchangetime());
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return adminInfoReturnJson;
    }

    @RequestMapping(value = "/api/admin/create",method = RequestMethod.POST, headers = "Accept=application/json")
    public AdminCreateReturnJson create(@RequestBody AdminEntity adminEntity){
        Date nowDate = DateUtil.getCreateTime();
        adminEntity.setAdmincreatetime(nowDate);
        adminEntity.setAdminchangetime(nowDate);
        AdminCreateReturnJson adminCreateReturnJson = new AdminCreateReturnJson();

        if(iAdminService.info(adminEntity.getAdminaccount()) != null){
            adminCreateReturnJson.setError_code("1311");
        }
        else {
            int flag = iAdminService.create(adminEntity);
            try {
                if (flag == 0) {
                    adminCreateReturnJson.setError_code("1312");
                } else {
                    adminCreateReturnJson.setError_code("0");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return adminCreateReturnJson;
    }

    @RequestMapping(value = "/api/admin/modify", method = RequestMethod.POST, headers = "Accept=application/json")
    public AdminModifyReturnJson modify(@RequestBody AdminEntity adminEntity){
        Date nowDate = DateUtil.getCreateTime();
        adminEntity.setAdminchangetime(nowDate);
        int flag = iAdminService.modify(adminEntity);


        AdminModifyReturnJson adminModifyReturnJson = new AdminModifyReturnJson();
        try {
            if (flag == 0) {
                adminModifyReturnJson.setError_code("1301");
            } else {
                adminModifyReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return adminModifyReturnJson;
    }

    @RequestMapping(value = "/api/admin/delete", method = RequestMethod.POST, headers = "Accept=application/json")
    public AdminDeleteReturnJson delete(@RequestBody AdminEntity adminEntity) {
        int result = iAdminService.delete(adminEntity.getAdminid());
        AdminDeleteReturnJson adminDeleteReturnJson = new AdminDeleteReturnJson();
        try {
            if (result == 0) {
                adminDeleteReturnJson.setError_code("1201");
            } else {
                adminDeleteReturnJson.setError_code("0");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return adminDeleteReturnJson;
    }

}
